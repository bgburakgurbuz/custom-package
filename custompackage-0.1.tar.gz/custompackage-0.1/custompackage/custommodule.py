def custom_print(name):
    print(f"Hi {name}!!")

