print("This package has been imported!")
__version__ = "0.1.0"

from .custommodule import custom_print
